
class Frame:

    def __init__(self):
        self.bit_data = []
        self.frame_info = {}
        self.stuff_bit_pos = []

        